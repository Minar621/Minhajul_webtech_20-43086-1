<html>
<head>
    
    <title></title>
</head>
<body>
<fieldset>
    <legend><h2>Profile Picture</h2></legend>
    <img src="1.png" width=100 height=100 alt="">
    <br><br>
    <input type="file">
    <br><br>
    <input type="submit" value="Submit">
</fieldset>
</body>
</html>